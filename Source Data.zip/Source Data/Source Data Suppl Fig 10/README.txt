File Descriptions
*****************

demo4_v3 *.csv are a comma-delimited files that contain raw simulation data for Fig 10 in the Supplement

TestFigureFrontiers_twopanel.py is a Python 3.7 script that uses raw simulation data to generate the top two rows of the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. see python script included).
