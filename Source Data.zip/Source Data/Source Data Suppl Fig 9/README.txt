File Descriptions
*****************

demo4_ *.csv are a comma-delimited files that contain raw simulation data for Fig 9 in the Supplement

TestFigureFrontiers_betamax.py is a Python 3.7 script that uses raw simulation data to generate the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. see python script included).
