File Descriptions
*****************

baseline1_Act2.csv is a comma-delimited file that contains raw simulation data for Fig 13 in the Supplement

baseline1_Fig.py is a Python 3.7 script that uses raw simulation data to generate the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. 
