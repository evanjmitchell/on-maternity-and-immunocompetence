File Descriptions
*****************

demo4_cfAct0pt5.csv is a comma-delimited file that contains raw simulation for innate immunity (original model) data for Fig 16 in the Supplement

demo5_Act0pt5.csv is a comma-delimited file that contains raw simulation for immune activation (modified model) data for Fig 16 in the Supplement

four-panel-1.py is a Python 3.7 script that uses csv file to generate the center panels of the figures (zero contours only)

Source Data *.xlsx are Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. see python script included).
