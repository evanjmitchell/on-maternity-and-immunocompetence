# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 16:02:11 2021

@author: gamwi
"""
import pandas as pd
import matplotlib.pyplot as plt

fid = "baseline1.csv"
df = pd.read_csv(fid, header=0)

N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
df["N"]=N

PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrRecof"] = PrRecof
df["PrRecom"] = PrRecom

PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrMortf"] = PrMortf
df["PrMortm"] = PrMortm

fig, ax = plt.subplots(2,2,sharex=True, figsize=(12,8))

for j in [0.1, 0.2, 0.3, 0.4, 0.5]:
    dfa = df[df["base_c"] == j]
    ax[0,0].plot(2*dfa["diff_c"]/j,dfa["alphaf"], '-r', label="female ($X=f$)")
    ax[0,0].plot(2*dfa["diff_c"]/j,dfa["alpham"], ':b', label="male ($X=m$)")

    ax[0,1].plot(2*dfa["diff_c"]/j,dfa["gammaf"], '-r', label="female ($X=f$)")
    ax[0,1].plot(2*dfa["diff_c"]/j,dfa["gammam"], ':b', label="male ($X=m$)")

    ax[1,0].plot(2*dfa["diff_c"]/j,dfa["PrMortf"], '-r', label="female")
    ax[1,0].plot(2*dfa["diff_c"]/j,dfa["PrMortm"], ':b', label="male")

    ax[1,1].plot(2*dfa["diff_c"]/j,dfa["PrRecof"], '-r', label="female")
    ax[1,1].plot(2*dfa["diff_c"]/j,dfa["PrRecom"], ':b', label="male")

    outfid = "source"+str(int(10*j)) +".xlsx"
    subdfa = dfa[["base_c", "diff_c", "alphaf", "alpham", "gammaf", "gammam","PrMortf", "PrMortm", "PrRecof", "PrRecom"]]
    subdfa.to_excel(outfid, index=False)

    if j == 0.1:
        ax[0,0].set_ylabel(r"parasite-induced mortality $\alpha_X^*$", fontsize=12)
        ax[0,1].set_ylabel(r"recovery rate $\gamma_X^*$", fontsize=12)
        ax[1,0].set_ylabel(r"case fatality", fontsize=12)
        ax[1,1].set_ylabel(r"case recovery", fontsize=12)
        
        ax[1,0].set_xlabel(r"$(c_f-c_m)/(0.5(c_f+c_m))$", fontsize=12)
        ax[1,1].set_xlabel(r"$(c_f-c_m)/(0.5(c_f+c_m))$", fontsize=12)
        
        ax[0,0].legend(frameon=False)
        ax[0,1].legend(frameon=False)
        ax[1,0].legend(frameon=False)
        ax[1,1].legend(frameon=False)

ax[0,0].text(-1,2.2,r"avg cost $=0.1$")
ax[0,1].text(-1,0.33,r"avg cost $=0.1$")
ax[1,0].text(-1,0.645,r"avg cost $=0.1$")
ax[1,1].text(-1,0.095,r"avg cost $=0.1$")

plt.show()
#plt.savefig("baseline1.pdf", dpi=600)