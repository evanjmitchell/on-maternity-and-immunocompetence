File Descriptions
*****************

demo4_v3.csv is a comma-delimited file that contain raw simulation data for Fig 8 in the Supplement (also Fig 6)

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. python script accompanying Fig 8 of the Supplement). 

Fig 6 corresponds to Fig 8 in Suppl (bottom two rows)