File Descriptions
*****************

demo4_v3.csv is a comma-delimited file that contains raw simulation data for Fig 8 in the Supplement

TestFigureContours.py is a Python 3.7 script that uses demo4_v3.csv to generate the top two rows of the figure

TestFigurePrContours.py is a Python 3.7 script that uses demo4_v3.csv to generate the bottom two rows of the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. see python script included).
