# Test figure 8 alternative with Contours

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Custom function that processes data in csv buffer
###################################################

def process_csv(filename):
    datafile = open(filename, "r")
    
    # empty arrays for cost diff and vert transmission rate
    cdiff = np.array([])
    v = np.array([])
    
    # empty array for height of function to plot
    h = np.array([])
    
    rowNumb = 0
    for row in datafile:
        row = row.strip('\n')
        row = row.split(',')
        if rowNumb == 0:
            # row has column headings
            for entry in row[1:]:
                cdiff = np.append(cdiff,float(entry))
        else:
            v = np.append(v,float(row[0]))
            for entry in row[1:]:
                h = np.append(h,float(entry))
        rowNumb += 1
    
    n = int( np.sqrt( np.size(h) ) )
    h = h.reshape(n,n)
    x,y = np.meshgrid(cdiff,v)

    return x, y, h

# Read data into a data frame that was created by Matlab
########################################################

df = pd.read_csv("demo4_v3.csv", header=0)

# Extract and process alpha data
################################

# Females
afdf = df.loc[:,["diff_c","prVert","alphaf"]]
afdf = afdf.pivot("prVert","diff_c", "alphaf")

# Males
amdf = df.loc[:,["diff_c","prVert","alpham"]]
amdf = amdf.pivot("prVert","diff_c", "alpham")

# Differences
alpha_diff = df["alphaf"] - df["alpham"]
df["Adiff"] = alpha_diff
acdf = df.loc[:,["diff_c","prVert","Adiff"]]
acdf = acdf.pivot("prVert","diff_c", "Adiff")

# Extract and process gamma data
################################

# Females
gfdf = df.loc[:,["diff_c","prVert","gammaf"]]
gfdf = gfdf.pivot("prVert","diff_c", "gammaf")

# Males
gmdf = df.loc[:,["diff_c","prVert","gammam"]]
gmdf = gmdf.pivot("prVert","diff_c", "gammam")

# Differences
gamma_diff = df["gammaf"] - df["gammam"]
df["Gdiff"] = gamma_diff
gcdf = df.loc[:,["diff_c","prVert","Gdiff"]]
gcdf = gcdf.pivot("prVert","diff_c", "Gdiff")

# put pivoted data frames into csv buffers
##########################################

# alpha
afdf.to_csv("TestFigureContours00.csv", sep=",")
acdf.to_csv("TestFigureContours01.csv", sep=",")
amdf.to_csv("TestFigureContours02.csv", sep=",")

# gamma
gfdf.to_csv("TestFigureContours10.csv", sep=",")
gcdf.to_csv("TestFigureContours11.csv", sep=",")
gmdf.to_csv("TestFigureContours12.csv", sep=",")

# Build the figure
##################

baseStr = "TestFigureContours"
filenames = np.array([[baseStr+"00.csv", baseStr+"01.csv",baseStr+"02.csv"],\
                      [baseStr+"10.csv", baseStr+"11.csv",baseStr+"12.csv"]])

titles=np.array([[r"$\alpha_f$", r"$\alpha_f-\alpha_m$", r"$\alpha_m$"],\
                 [r"$\gamma_f$", r"$\gamma_f-\gamma_m$", r"$\gamma_m$"]])
    
from matplotlib import cm

blue_cmap = cm.get_cmap('Blues')
rBlues=blue_cmap.reversed()

fig, ax = plt.subplots(2,3,figsize=(13,7),sharex=True, sharey=True)

# go panel by panel

# First Row
###########

# left
x,y,z = process_csv(filenames[0,0])
ax[0,0].contour(2*x,y,z,colors='black',levels=20,linewidths=0.5)
cs1 = ax[0,0].contourf(2*x,y,z,cmap='Greys',levels=20)
fig.colorbar(cs1, ax=ax[0,0], shrink=0.9)

# middle
x,y,z = process_csv(filenames[0,1])
#cs2=ax[0,1].contourf(2*x,y,z,levels=0.1*np.arange(-25,0),cmap=rBlues)
#ax[0,1].contourf(2*x,y,z,levels=0.1*np.arange(1,10),cmap='Reds')
ax[0,1].contour(2*x,y,z,levels=[0],colors=['k'],linewidths=2)
import matplotlib.colors as mcolors
levels=23
mycmap=mcolors.LinearSegmentedColormap.from_list(name='red_white_blue',\
                                          colors =[(0, 0, 1),\
                                                   (0.1,0.1,1),\
                                                   (0.2,0.2,1),\
                                                   (0.3,0.3,1),\
                                                   (0.4,0.4,1),\
                                                   (0.6,0.6,1),\
                                                   (0.7,0.7,1),\
                                                   (0.8,0.8,1),\
                                                   (0.9,0.9,1),\
                                                   (1,1,1),\
                                                   (1, 1., 1),\
                                                   (1,0.7,0.7)],\
                                                   N=levels,)
cs2=ax[0,1].contourf(2*x,y,z,levels=levels,cmap=mycmap)
fig.colorbar(cs2,ax=ax[0,1], shrink=0.9)
#fig.colorbar(cs3, ax=ax[0,1], shrink=0.5)

# right
x,y,z = process_csv(filenames[0,2])
ax[0,2].contour(2*x,y,z,colors='black',levels=20,linewidths=0.5)
cs3=ax[0,2].contourf(2*x,y,z,cmap='Greys',levels=20)
fig.colorbar(cs3, ax=ax[0,2], shrink=0.9)

# Second Row
############

# left
x,y,z = process_csv(filenames[1,0])
ax[1,0].contour(2*x,y,z,colors='black',levels=20,linewidths=0.5)
cs4=ax[1,0].contourf(2*x,y,z,cmap='Greys',levels=20)
fig.colorbar(cs4, ax=ax[1,0], shrink=0.9)

# middle
x,y,z = process_csv(filenames[1,1])
#ax[1,1].contourf(2*x,y,z,levels=0.1*np.arange(-25,0),cmap=rBlues)
#ax[1,1].contourf(2*x,y,z,levels=0.1*np.arange(1,16),cmap='Reds')
ax[1,1].contour(2*x,y,z,levels=[0],colors=['k'],linewidths=2)
levels=23
othercmap=mcolors.LinearSegmentedColormap.from_list(name='red_white_blue',\
                                          colors =[(0.2,0.2,1),\
                                                   (0.4,0.4,1),\
                                                   (0.6,0.6,1),\
                                                   (0.8,0.8,1),\
                                                   (1,1,1),\
                                                   (1,1,1),\
                                                   (1,0.8,0.8),\
                                                   (1,0.6,0.6),\
                                                   (1,0.4,0.4),\
                                                   (1,0.2,0.2),\
                                                   (1,0,0)],\
                                                   N=levels,)
cs5=ax[1,1].contourf(2*x,y,z,levels=levels,cmap=othercmap)
fig.colorbar(cs5, ax=ax[1,1], shrink=0.9)

# right
x,y,z = process_csv(filenames[1,2])
ax[1,2].contour(2*x,y,z,colors='black',levels=20,linewidths=0.5)
cs6 = ax[1,2].contourf(2*x,y,z,cmap='Greys',levels=20)
fig.colorbar(cs6, ax=ax[1,2], shrink=0.9)

# Labels and Titles
####################

for i in range(2):
    ax[i,0].set_ylabel(r"vert transmission, $v$", fontsize=16)
    
for j in range(3):
    ax[1,j].set_xlabel(r"cost difference, $c_f-c_m$",fontsize=16)

for i in range(2):
    for j in range(3):
        ax[i,j].set_title(titles[i,j],fontsize=16)

plt.tight_layout()
#plt.savefig("TestFigureContours.svg", dpi=600)
plt.show()