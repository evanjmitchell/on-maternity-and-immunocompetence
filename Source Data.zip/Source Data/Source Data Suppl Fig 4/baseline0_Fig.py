# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 14:54:47 2021

@author: gamwi
"""
import pandas as pd
import matplotlib.pyplot as plt

fig, ax = plt.subplots(nrows=2, ncols=2, sharex=True, figsize=(12,8))

fid = ["baseline0.csv", "baseline01.csv"]

for j in [0,1]:
    df = pd.read_csv(fid[j], header=0)
    
    N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
    df["N"]=N
    
    PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["PrRecof"] = PrRecof
    df["PrRecom"] = PrRecom
    
    PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["PrMortf"] = PrMortf
    df["PrMortm"] = PrMortm
    
    ax[0,0].plot(df["base_c"], df["alphaf"], '-r', label=r"female ($X=f$)")
    ax[0,0].plot(df["base_c"], df["alpham"], ':b', label=r"male, ($X=m$)")
    if j == 0:
        ax[0,0].legend(frameon=False)
    ax[0,0].set_ylabel(r"parasite-induced mortality $\alpha_X^*$", fontsize=12)
    
    ax[0,1].plot(df["base_c"], df["gammaf"], '-r', label=r"female, ($X=f$)")
    ax[0,1].plot(df["base_c"], df["gammam"], ':b', label=r"male, ($X=m$)")
    ax[0,1].set_ylabel(r"recover rate, $\gamma_X^*$", fontsize=12)
    if j == 0:
        ax[0,1].legend(frameon=False)
    
    ax[1,0].plot(df["base_c"], df["PrMortf"], '-r', label=r"female")
    ax[1,0].plot(df["base_c"], df["PrMortm"], ':b', label=r"male")
    ax[1,0].set_ylabel(r"case fatality", fontsize=12)
    if j == 0:
        ax[1,0].legend(frameon=False)
    ax[1,0].set_xlabel(r"cost of recovery, $c_X$", fontsize=12)
    
    ax[1,1].plot(df["base_c"], df["PrRecof"], '-r', label=r"female")
    ax[1,1].plot(df["base_c"], df["PrRecom"], ':b', label=r"male")
    ax[1,1].set_ylabel(r"case recovery")
    if j == 0:
        ax[1,1].legend(frameon=False)
    ax[1,1].set_xlabel(r"cost of recovery, $c_X$", fontsize=12)

ax[0,0].text(0.125,2.05,r"$b_{max}=2$")
ax[0,0].text(0.1,2.4,r"$b_{max}=4$")

ax[0,1].text(0.1,0.1,r"$b_{max}=2$")
ax[0,1].text(0.13,0.25,r"$b_{max}=4$")

ax[1,0].text(0.1,0.67,r"$b_{max}=2$")
ax[1,0].text(0.1,0.623,r"$b_{max}=4$")

ax[1,1].text(0.1,0.035,r"$b_{max}=2$")
ax[1,1].text(0.125,0.065,r"$b_{max}=4$")

plt.show()
#plt.savefig("baseline0.pdf", dpi=600)