File Descriptions
*****************

baseline0.csv is a comma-delimited file that contains raw simulation data for Fig 4 in the Supplement

baseline01.csv is a comma-delimited file that contains raw simulation data for Fig 4 in the Supplement

baseline0_Fig.py is a Python 3.7 script that uses baseline0.csv and baseline01.csv to generate the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format
