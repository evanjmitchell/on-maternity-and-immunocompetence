File Descriptions
*****************

demo4_cfAct0pt5.csv and demo5_Act0pt5.csv are comma-delimited files that contain raw simulation data for Fig 5

Source Data *.xlsx are Excel files containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. python script accompanying Fig 8 of the Supplement). Separate source files are provided for innate and adaptive immunity, respectively.