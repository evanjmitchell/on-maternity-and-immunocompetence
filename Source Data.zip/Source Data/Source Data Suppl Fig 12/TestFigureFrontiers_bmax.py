# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 11:03:28 2022

@author: gamwi
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def process_csv(filename):
    datafile = open(filename, "r")
    
    # empty arrays for cost diff and vert transmission rate
    cdiff = np.array([])
    v = np.array([])
    
    # empty array for height of function to plot
    h = np.array([])
    
    rowNumb = 0
    for row in datafile:
        row = row.strip('\n')
        row = row.split(',')
        if rowNumb == 0:
            # row has column headings
            for entry in row[1:]:
                cdiff = np.append(cdiff,float(entry))
        else:
            v = np.append(v,float(row[0]))
            for entry in row[1:]:
                h = np.append(h,float(entry))
        rowNumb += 1
    
    n = int( np.sqrt( np.size(h) ) )
    h = h.reshape(n,n)
    x,y = np.meshgrid(cdiff,v)
    
    datafile.close()

    return x, y, h

# files should be ordered based on betaC2

files = ["demo4_v3.csv",\
         "demo4_bmax_2pt5.csv",\
         "demo4_bmax_3pt0.csv",\
         "demo4_bmax_3pt25.csv",\
         "demo4_bmax_3pt5.csv"]

headers = ["Adiff", "Gdiff", "DeltaCM", "DeltaPrRecov"]

counter =1

for file in files:
    # read data file into dataframe
    ###############################
    df = pd.read_csv(file, header=0)
    
    # add difference in alphas to dataframe
    #######################################
    alpha_diff = df["alphaf"] - df["alpham"]
    df["Adiff"] = alpha_diff
    
    # add difference in gammas to dataframe
    #######################################
    gamma_diff = df["gammaf"] - df["gammam"]
    df["Gdiff"] = gamma_diff
    
    # add total popsize to dataframe
    ################################
    N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
    df["N"]=N

    # add Delta Case Mortality to dataframe 
    #######################################
    PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["DeltaCM"] = PrMortf-PrMortm

    # add Delta Pr Recovery to dataframe
    ####################################
    PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["DeltaPrRecov"] = PrRecof-PrRecom
    
    subdf=df[["bmax", "diff_c", "prVert", "Adiff", "Gdiff", "DeltaCM", "DeltaPrRecov"]]
    outfid="source"+str(counter)+".xlsx"
    subdf.to_excel(outfid,index=False)
    counter+=1
    
    for header in headers:
        subdf = df.loc[:,["diff_c","prVert",header]]
        subdf = subdf.pivot("prVert","diff_c", header)

        outfile = header + file        
        subdf.to_csv(outfile, sep=",")

fig, ax = plt.subplots(2,2,figsize=(9,8),sharex=True, sharey=True)

colors = ['blueviolet', 'royalblue', 'lime', 'gold', 'red' ]

colorcount = 0

for file in files:
    # top left panel
    outfile = "Adiff" + file
    x,y,z = process_csv(outfile)
    ax[0,0].contour(2*x,y,z,levels=[0],colors=[colors[colorcount]],linewidths=2)
    
    # top right panel
    outfile = "Gdiff" + file
    x,y,z = process_csv(outfile)
    ax[1,0].contour(2*x,y,z,levels=[0],colors=[colors[colorcount]],linewidths=2)

    # bottom left
    outfile = "DeltaCM" + file
    x,y,z = process_csv(outfile)
    ax[0,1].contour(2*x,y,z,levels=[0],colors=[colors[colorcount]],linewidths=2)

    # bottom right
    outfile = "DeltaPrRecov" + file
    x,y,z = process_csv(outfile)
    ax[1,1].contour(2*x,y,z,levels=[0],colors=[colors[colorcount]],linewidths=2)
    
    colorcount += 1

ax[0,0].text( 0.0, 0.6, r"$\alpha_f < \alpha_m$", fontsize=14, color='k')
ax[1,0].text( -0.1, 0.6, r"$\gamma_f > \gamma_m$", fontsize=14, color='k')
ax[0,1].text( -0.1, 0.7, r"Mortality f < Mortality m", fontsize=14, color='k')
ax[1,1].text( -0.125, 0.7, r"Recovery f > Recovery m", fontsize=12, color='k')

ax[1,0].text( 0.07, 0.75, r"$b_{max}=2.0$", color=colors[0])
ax[1,0].text( 0.07, 0.6, r"$b_{max}=2.5$", color=colors[1])
ax[1,0].text( 0.07, 0.45, r"$b_{max}=3.0$", color=colors[2])
ax[1,0].text( 0.07, 0.3, r"$b_{max}=3.25$", color=colors[3])
ax[1,0].text( 0.07, 0.15, r"$b_{max}=3.5$", color=colors[4])


for i in range(2):
    ax[i,0].set_ylabel(r"vert transmission, $v$", fontsize=16)
    
for j in range(2):
    ax[1,j].set_xlabel(r"cost difference, $c_f-c_m$",fontsize=16)

titles=np.array([[r"$\alpha_f - \alpha_m$", r"$\Delta$ Case Mortality"],\
        [r"$\gamma_f-\gamma_m$", r"$\Delta$ Pr Recovery"]])

for i in range(2):
    for j in range(2):
        ax[i,j].set_title(titles[i,j],fontsize=16)
        
plt.tight_layout()
#plt.savefig("TestFigureFrontiersbmax.pdf", dpi=600)
plt.show()