# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 16:02:11 2021

@author: gamwi
"""
import pandas as pd
import matplotlib.pyplot as plt

fid = "baseline2_Act.csv"
df = pd.read_csv(fid, header=0)

#df = df_orig[df_orig["p_ESS?"]==True]

N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
df["N"]=N

PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrRecof"] = PrRecof
df["PrRecom"] = PrRecom

PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrMortf"] = PrMortf
df["PrMortm"] = PrMortm

fig, ax = plt.subplots(2,2,sharex=True, figsize=(12,8))

subdf=df[["base_c", "prVert", "alphaf", "alpham", "gammaf", "gammam", "PrMortf", "PrMortm", "PrRecof", "PrRecom"]]
subdf.to_excel("SourceData.xlsx",index=False)

for j in [0.5,0.75,1,1.25]:
    dfa = df[df["base_c"] == j]
    
    #if j==1.25:
   #     color='purple'
    #else:
     #   color='green'
        
    ax[0,0].plot(dfa["prVert"],dfa["alphaf"], '-', color='red', label="female ($X=f$)")
    ax[0,0].plot(dfa["prVert"],dfa["alpham"], ':', color='blue', label="male ($X=m$)")

    ax[0,1].plot(dfa["prVert"],dfa["gammaf"], '-', color='red', label="female ($X=f$)")
    ax[0,1].plot(dfa["prVert"],dfa["gammam"], ':', color='blue', label="male ($X=m$)")

    ax[1,0].plot(dfa["prVert"],dfa["PrMortf"], '-', color='red', label="female")
    ax[1,0].plot(dfa["prVert"],dfa["PrMortm"], ':', color='blue', label="male")

    ax[1,1].plot(dfa["prVert"],dfa["PrRecof"], '-', color='red', label="female")
    ax[1,1].plot(dfa["prVert"],dfa["PrRecom"], ':', color='blue', label="male")

    if j == 0.5:
        ax[0,0].set_ylabel(r"parasite-induced mortality $\alpha_X^*$", fontsize=12)
        ax[0,1].set_ylabel(r"recovery rate $\gamma_X^*$", fontsize=12)
        ax[1,0].set_ylabel(r"case fatality", fontsize=12)
        ax[1,1].set_ylabel(r"case recovery", fontsize=12)
        
        ax[1,0].set_xlabel(r"probability vertical transmission $v$", fontsize=12)
        ax[1,1].set_xlabel(r"probability vertical transmission $v$", fontsize=12)
        
        ax[0,0].legend(frameon=False)
        ax[0,1].legend(frameon=False)
        ax[1,0].legend(frameon=False)
        ax[1,1].legend(frameon=False)
        
ax[0,0].text(0.15,2,r"$c_X = 0.5$",color='blue')
ax[0,0].text(0.15,1.6,r"$c_X = 1.25$", color='blue')
ax[0,0].text(0.4,0.75,r"$c_X = 0.5$",color='red')
ax[0,0].text(0.4,0.15,r"$c_X = 1.25$", color='red')

ax[1,0].text(0.05,0.57,r"$c_X = 0.5$")
ax[1,0].text(0.05,0.7,r"$c_X = 1.25$")
ax[1,0].text(0.525,0.3,r"$c_X = 0.5$",color='red')
ax[1,0].text(0.525,0.05,r"$c_X = 1.25$", color='red')

ax[0,1].text(0.4,0.17,r"$c_X = 0.5$")
ax[0,1].text(0.4,0.025,r"$c_X = 1.25$")

ax[1,1].text(0.55,0.065,r"$c_X = 0.5$")
ax[1,1].text(0.55,0.019,r"$c_X = 1.25$")

plt.show()
#plt.savefig("baseline2_Act.pdf", dpi=600)