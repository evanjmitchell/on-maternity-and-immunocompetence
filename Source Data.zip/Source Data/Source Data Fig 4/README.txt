File Descriptions
*****************

demo4_v3 *.csv are a comma-delimited file that contain raw simulation data for Fig 8 in the Supplement and Fig 10 in the Supplement

demo5 *.csv are a comma-delimited file that contain raw simulation data for Fig 8 in the Supplement and Fig 11 in the Supplement

Source Data Panels A and Bi.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. python script accompanying Fig 8 of the Supplement). 

Source Data Panel Bii.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. python script accompanying Fig 11 of the Supplement).

Source Data Panel Biii.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. python script accompanying Fig 10 of the Supplement). 

Panel A corresponds to Fig 8 in Suppl

Panel Bii corresponds to Fig 11 in Suppl

Panel Biii corresponds to Fig 10 in Suppl
