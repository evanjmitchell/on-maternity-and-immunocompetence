File Descriptions
*****************

baseline2.csv is a comma-delimited file that contains raw simulation data for Fig 7 in the Supplement

baseline2_Fig.py is a Python 3.7 script that uses baseline2.csv to generate the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format
