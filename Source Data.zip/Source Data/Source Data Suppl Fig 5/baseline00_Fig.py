# -*- coding: utf-8 -*-
"""
Created on Tue Dec 28 10:51:47 2021

@author: gamwi
"""

import pandas as pd
import matplotlib.pyplot as plt

fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(12,8))

fid = ["baseline0.csv", "baseline01.csv"]
outfid = ["source1.xlsx", "source2.xlsx"]
for j in [0,1]:
    df = pd.read_csv(fid[j], header=0)
    
    N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
    df["N"]=N
    
    PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["PrRecof"] = PrRecof
    df["PrRecom"] = PrRecom
    
    PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
    PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
    df["PrMortf"] = PrMortf
    df["PrMortm"] = PrMortm
    
    ax[0,j].plot(df["gammaf"]+df["N"]*df["mu"], df["PrMortf"], '-r', label=r"female")
    ax[0,j].plot(df["gammam"]+df["N"]*df["mu"], df["PrMortm"], ':b', label=r"male")
    #ax[0].legend(frameon=False)
    #ax[1,0].set_xlabel(r"cost of recovery, $c_X$", fontsize=12)
    
    ax[1,j].plot(df["gammaf"]+df["N"]*df["mu"], df["PrRecof"], '-r', label=r"female")
    ax[1,j].plot(df["gammam"]+df["N"]*df["mu"], df["PrRecom"], ':b', label=r"male")
    
    varf = df["gammaf"]+df["mu"] * df["N"]
    varm = df["gammam"]+df["mu"] * df["N"]
    df["HorizVarf"] = varf
    df["HorizVarm"] = varm
    #ax[1].legend(frameon=False)
    #ax[1,1].set_xlabel(r"cost of recovery, $c_X$", fontsize=12)
    subdf = df[["bmax","HorizVarf","HorizVarm","PrMortf", "PrMortm", "PrRecof", "PrRecom"]]

    subdf.to_excel(outfid[j], index=False)

ax[0,0].text(1,0.675,r"$b_{max}=2$",fontsize=12)
ax[1,0].text(0.92,0.05,r"$b_{max}=2$",fontsize=12)

ax[0,1].text(1.55,0.62875,r"$b_{max}=4$",fontsize=12)
ax[1,1].text(1.4,0.065,r"$b_{max}=4$",fontsize=12)

ax[0,0].set_ylabel(r"case fatality", fontsize=12)
ax[1,0].set_ylabel(r"case recovery", fontsize=12)
ax[1,0].set_xlabel(r"$\mu\, \bar N + \gamma_X^*$", fontsize=12)
ax[1,1].set_xlabel(r"$\mu\, \bar N + \gamma_X^*$", fontsize=12)
plt.show()
#plt.savefig("baseline00.pdf", dpi=600)