# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 16:02:11 2021

@author: gamwi
"""
import pandas as pd
import matplotlib.pyplot as plt

fid = "baseline1_revised.csv"
df = pd.read_csv(fid, header=0)

N = df["Sfbar"]+df["Smbar"]+df["Ifbar"]+df["Imbar"]
df["N"]=N

PrRecof = df["gammaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrRecom = df["gammam"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrRecof"] = PrRecof
df["PrRecom"] = PrRecom

PrMortf = df["alphaf"] / (df["alphaf"]+df["gammaf"]+df["mu"] * df["N"])
PrMortm = df["alpham"] / (df["alpham"]+df["gammam"]+df["mu"] * df["N"])
df["PrMortf"] = PrMortf
df["PrMortm"] = PrMortm

fig, ax = plt.subplots(2,2,sharex=False, figsize=(10,10))

for j in [0.01, 0.025, 0.1, 0.25, 1]:
    dfa = df[df["base_c"] == j]
    cdiff = 2*dfa["diff_c"]/j
    
    x = dfa["alphaf"]
    y = dfa["alpham"]
    ax[0,0].plot(x[cdiff<0],y[cdiff<0], '-r')
    ax[0,0].plot(x[cdiff>0],y[cdiff>0], '-b')
    
    x = dfa["gammaf"]
    y = dfa["gammam"]
    ax[0,1].plot(x[cdiff<0], y[cdiff<0],'-r')
    ax[0,1].plot(x[cdiff>0], y[cdiff>0],'-b')

    x = dfa["PrMortf"]
    y = dfa["PrMortm"]
    ax[1,0].plot(x[cdiff<0], y[cdiff<0],'-r')
    ax[1,0].plot(x[cdiff>0], y[cdiff>0],'-b')
    
    x=dfa["PrRecof"]
    y=dfa["PrRecom"]
    ax[1,1].plot(x[cdiff<0], y[cdiff<0],'-r')
    ax[1,1].plot(x[cdiff>0], y[cdiff>0],'-b')
    
    ax[0,0].plot([1.8,2.8],[1.8,2.8],':', color='gray')
    ax[0,1].plot([0,1.0],[0,1.0],':', color='gray')
    ax[1,0].plot([0.59,0.69],[0.59,0.69],':', color='gray')
    ax[1,1].plot([0,0.2],[0,0.2],':', color='gray')
    
    outfid = "source" + str( int(1000*j) ) + ".xlsx"
    subdfa = dfa[["base_c", "diff_c", "alphaf", "alpham", "gammaf", "gammam"]]
    subdfa.to_excel(outfid, index=False)
    
ax[0,0].set_xlabel(r"parasite-induced mortality $\alpha_f^*$", fontsize=12)
ax[0,0].set_ylabel(r"parasite-induced mortality $\alpha_m^*$", fontsize=12)

ax[0,1].set_xlabel(r"recovery rate $\gamma_f^*$", fontsize=12)
ax[0,1].set_ylabel(r"recovery rate $\gamma_m^*$", fontsize=12)

ax[1,0].set_xlabel(r"case fatality $f$", fontsize=12)
ax[1,0].set_ylabel(r"case fatality $m$", fontsize=12)
        
ax[1,1].set_xlabel(r"case recovery $f$", fontsize=12)
ax[1,1].set_ylabel(r"case recovery $m$", fontsize=12)
        
plt.show()
#plt.savefig("baseline1_revised_Alt2.pdf", dpi=600)