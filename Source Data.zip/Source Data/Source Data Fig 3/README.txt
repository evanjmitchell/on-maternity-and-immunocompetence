File Descriptions
*****************

baseline1_revised.csv is a comma-delimited file that contains raw simulation data for Fig 3

baseline2_revised.csv is a comma-delimited file that contains raw simulation data for Fig 3

baseline1_revised_Fig_Alt2.py is a Python 3.7 script that uses baseline1_revised.csv to create versions of Panels C and D

baseline2_Fig_Alt2.py is a Python 3.7 script that uses baseline1_revised.csv and baseline2_revised.csv to create versions of Panels B-D 

Source Data Panel *.xlsx are Excel files containing all data for the corresponding panel of the figure in the recommended format
