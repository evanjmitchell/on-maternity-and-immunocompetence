# -*- coding: utf-8 -*-
"""
Created on Thu Dec 23 16:02:11 2021

@author: gamwi
"""
import pandas as pd
import matplotlib.pyplot as plt

fid1 = "baseline1_revised.csv"
df1 = pd.read_csv(fid1, header=0)

fid2 = "baseline2_revised.csv"
df2 = pd.read_csv(fid2, header=0)

fig, ax = plt.subplots(2,2,sharex=False, sharey=False, figsize=(10,10))

for j in [0.01, 0.025, 0.1, 0.25, 1, 2.5]: # eliminate 0.4 and 0.5
    dfa = df1[df1["base_c"] == j]
    
    cdiff = 2*dfa["diff_c"]/j
    
    x = dfa["alphaf"]
    y = dfa["alpham"]
    ax[0,0].plot(x[cdiff<0],y[cdiff<0], '-r')
    ax[0,0].plot(x[cdiff>0],y[cdiff>0], '-b')
    
    x = dfa["gammaf"]
    y = dfa["gammam"]
    ax[0,1].plot(x[cdiff<0], y[cdiff<0],'-r')
    ax[0,1].plot(x[cdiff>0], y[cdiff>0],'-b')

    dfa = df2[df2["base_c"] == j]
    ax[1,0].plot(dfa["alphaf"],dfa["alpham"], '-', label="female ($X=f$)", color='b')
    ax[1,1].plot(dfa["gammaf"],dfa["gammam"], '-', label="male ($X=m$)", color='r')

    if j==0.01:
        subdfa=dfa[["base_c", "prVert", "alphaf", "alpham", "gammaf", "gammam"]]
        subdfa.to_excel("Source.xlsx", index=False)
        
for idx in range(2):
    ax[idx,0].plot([0,3],[0,3],':', color='gray')
    ax[idx,1].plot([0,1.8],[0,1.8],':', color='gray')

    ax[idx,0].set_xlabel(r"parasite-induced mortality $\alpha_f^*$", fontsize=12)
    ax[idx,0].set_ylabel(r"parasite-induced mortality $\alpha_m^*$", fontsize=12)

    ax[idx,1].set_xlabel(r"recovery rate $\gamma_f^*$", fontsize=12)
    ax[idx,1].set_ylabel(r"recovery rate $\gamma_m^*$", fontsize=12)
    
    ax[idx,0].set_xlim(1.2,3.0)
    ax[idx,0].set_ylim(1.2,3.0)
    
    ax[idx,1].set_xlim(0,1.8)
    ax[idx,1].set_ylim(0,1.8)

plt.show()
#plt.savefig("option3.pdf", dpi=600)