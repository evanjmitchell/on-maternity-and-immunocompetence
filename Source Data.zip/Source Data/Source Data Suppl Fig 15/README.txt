File Descriptions
*****************

demo4_Act4.csv is a comma-delimited file that contains raw simulation data for Fig 15 in the Supplement

TestFigureContoursAct.py is a Python 3.7 script that uses csv file to generate the figure

Source Data.xlsx is an Excel file containing all data for the figure in the recommended format. Note that these data must be used in conjunction with a computational tool that interpolates contours (e.g. see python script included).
